dep/identify.d: src/identify.c inc/br.h inc/fat12.h inc/fat16.h \
 inc/fat16fd.h inc/fat32.h inc/fat32nt.h inc/fat32fd.h inc/ntfs.h \
 inc/nls.h inc/identify.h
