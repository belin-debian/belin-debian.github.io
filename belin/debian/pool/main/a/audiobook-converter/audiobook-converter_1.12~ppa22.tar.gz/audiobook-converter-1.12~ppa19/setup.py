#!/usr/bin/env /usr/bin/python3
#Audiobook Converter - an audiobook converter application for
#visually impaired users
#Copyright (C) 2009-2014,  Attila Hammerr <hammera at pickup.hu>
#
#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU Affero General Public License as
#published by the Free Software Foundation, either version 3 of the
#License, or (at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU Affero General Public License for more details.
#
#You should have received a copy of the GNU Affero General Public
#License along with this program.  If not,
#see http://www.gnu.org/licenses/.
from DistUtilsExtra.auto import setup


setup(
    name='audiobook-converter',
    version='1.11-dev',
    description='Convert text viles for audio books with mp3 format',
    url='',
    license='GPL v2 or later',
    author='Attila Hammer',
    author_email='hammera@pickup.hu',
    data_files=[('share/applications', ['extra/mimeapps.list']),
    ('share/audiobook-converter', ['src/hangoskonyv']),
    ('share/audiobook-converter', ['src/message'])],
    scripts=['hangoskonyv', 'message', 'audiobook-converter'],
)

