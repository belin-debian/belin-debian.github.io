#!/bin/sh
export GTK_IM_MODULE=ibus
export QT_IM_MODULE=ibus
export XMODIFIERS=@im=ibus
if [ -d "$HOME/.gconf/apps/metacity" ] ; then
    rm -r $HOME/.gconf/apps/metacity
fi
setxkbmap hu
