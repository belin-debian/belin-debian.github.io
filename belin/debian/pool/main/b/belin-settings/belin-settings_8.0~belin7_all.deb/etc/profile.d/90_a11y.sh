#!/bin/sh
export ACCESSIBILITY_ENABLED=1
export GNOME_ACCESSIBILITY=1
export GTK_OVERLAY_SCROLLING=0
export GTK_MODULES=gail:atk-bridge:canberra-gtk-module
export DERIVATIVE_NAME=BeLin
export QT_ACCESSIBILITY=1
export QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1
export DCONF_PROFILE=keybinding
export GTK_IM_MODULE=ibus
export QT_IM_MODULE=ibus
export XMODIFIERS=@im=ibus
export ZPOOL_VDEV_NAME_PATH=1
if [ -d "$HOME/.gconf/apps/metacity" ] ; then
    rm -r $HOME/.gconf/apps/metacity
fi
setxkbmap -layout "hu,us" -option "grp:shifts_toggle"

for i in Desktop/*
do
if [[ -f $i ]]; then
chmod +x "$i"
gio set "$i" "metadata::trusted" yes
fi
done
