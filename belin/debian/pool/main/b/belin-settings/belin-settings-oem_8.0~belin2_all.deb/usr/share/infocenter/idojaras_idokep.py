#!coding: utf-8
from lxml import html
from gi.repository import Gtk as gtk
import subprocess, feedparser
cimek={}
cimek['terkep0']='Mai időjárás'
cimek['terkep1']='hosszútávú előrejelzés'
cimek['terkep2']=''
cimek['szolg_36ora']='36 órás előrejelzés'
cimek['szolg_balaton']='Balatoni időjárás'
cimek['szolg_pollen']='Pollenjelentés'
cimek['szolg_kozlekedes']='Közlekedésmeteorológiai információk'
cimek['szolg_orvos']='Orvosmeteorológia'
cimek['szolg_hojelentes']='Hójelentés'
def main():
    try:
        h=feedparser.parse('https://adat.idokep.hu/rss/subscribe/infoalap_forecast_5396e3.xml')
        cim=h['feed']['title']
        alcim=h['feed']['subtitle']
        html_tartalom='<html>\n<head>\n<meta charset="utf-8">\n<title>'+cim+' '+alcim+'</title>\n</head>\n<body>\n<h1>'+cim+' '+alcim+'</h1>\n<div>Forrás: <a href="http://www.idokep.hu">Időkép.hu</a>\n</div>\n<div></div>\n'
        for i in range(0, len(h['entries'])):
            cimsor=cimek[h['entries'][i]['title']]
            if len(cimsor)!=0:
                if len(h['entries'][i]['summary'])!=0:
                    html_tartalom=html_tartalom+'<h2>'+cimsor+'</h2>\n<p>'+h['entries'][i]['summary'].replace('\n', '</p>\n<p>')+'</p>\n'
            else:
                if len(h['entries'][i]['summary'])!=0:
                    html_tartalom=html_tartalom+'<p>'+h['entries'][i]['summary'].replace('\n', '</p>\n<p>')+'</p>\n'
        html_tartalom=html_tartalom+'</body>\n</html>'
        html.open_in_browser(html.document_fromstring(html_tartalom), encoding='utf-8')
    except:
        dialog = gtk.MessageDialog(None, 0, gtk.MessageType.ERROR,
            gtk.ButtonsType.OK, "A kiválasztott funkcióhoz tartozó adatforrás jelenleg nem érhető el. Próbálja meg később.")
        dialog.run()
        sys.exit()

