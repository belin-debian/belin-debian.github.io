module liblouis.org/generate-display-names

go 1.24.0

require golang.org/x/text v0.32.0
