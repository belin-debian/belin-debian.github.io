#!/bin/bash
set -e
for home in `cat /etc/passwd |grep "/bin/bash" |grep /home|cut -d ":" -f6|sort`; do
{
echo $home
if [ "$home" != "/home/lost+found" ]  && [ "$home" != "/home/remastersys" ]; then
file=$home/.local/share/applications/debian-installer-launcher.desktop
if [ -e $file ]; then
rm $home/.local/share/applications/debian-installer-launcher*
fi
cp -r /etc/skel/.profile $home
cp /etc/skel/.config/braille-editor.conf $home/.config
mkdir -p $home/.local/share
cp -r /etc/skel/.local/share/orca $home/.local/share/orca
usernev=`echo |basename $home`
chown -hR $usernev:$usernev $home/.profile
chown -hR $usernev:$usernev $home/.purple
chown -hR $usernev:$usernev $home/.local/share/orca
chown -hR $usernev:$usernev $home/.local/share
fi
}
done
if [ -e /usr/bin/ertesito ]; then
rm /usr/bin/ertesito
fi
