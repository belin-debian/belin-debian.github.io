# https://gitlab.gnome.org/GNOME/orca/-/issues/358
# ruff: noqa: F401
from .script import Script
from .speech_generator import SpeechGenerator
