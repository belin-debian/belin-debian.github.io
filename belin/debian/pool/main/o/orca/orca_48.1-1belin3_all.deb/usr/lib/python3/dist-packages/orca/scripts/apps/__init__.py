"""Orca's application scripts."""

__all__ = ['evince',
           'evolution',
           'gajim',
           'gedit',
           'gnome-shell',
           'kwin',
           'notification-daemon',
           'pidgin',
           'soffice',
           'SeaMonkey',
           'smuxi-frontend-gnome',
           'Thunderbird',
           'unity',
           'xfwm4']
