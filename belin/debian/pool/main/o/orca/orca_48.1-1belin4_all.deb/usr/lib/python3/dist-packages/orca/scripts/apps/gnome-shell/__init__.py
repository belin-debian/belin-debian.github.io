"""Custom script for gnome-shell."""

# pylint: disable=invalid-name
# pylint: disable=duplicate-code

# https://gitlab.gnome.org/GNOME/orca/-/issues/358
# ruff: noqa: F401
from .script import Script
