# https://gitlab.gnome.org/GNOME/orca/-/issues/358
# ruff: noqa: F401
from .script import Script
