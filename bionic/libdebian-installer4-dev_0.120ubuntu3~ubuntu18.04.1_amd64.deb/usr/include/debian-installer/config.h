/* include/debian-installer/config.h.  Generated from config.h.in by configure.  */
/* Library version */
#define LIBDI_VERSION 4.0.8

/* Library version - major */
#define LIBDI_VERSION_MAJOR 4

/* Library version - minor */
#define LIBDI_VERSION_MINOR 0

/* Library version - revision */
#define LIBDI_VERSION_REVISION 8

